import saDigitalSMS from "./components/sa-digital-sms.js";

window.customElements.define("sa-digital-sms", saDigitalSMS);
