import saDigitalEmail from "./components/sa-digital-email.js";

window.customElements.define("sa-digital-email", saDigitalEmail);
