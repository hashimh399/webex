import saGiftCard from "./components/sa-gift-card.js";

// window.customElements.define("sa-gift-card", saGiftCard);
window.customElements.define("sa-gift-card", saGiftCard);
