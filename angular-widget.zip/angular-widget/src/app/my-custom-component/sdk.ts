import { Desktop } from '@wxcc-desktop/sdk';

/**
 * Replace the namespace here according to your widget/component name
 */
export const logger = Desktop.logger.createLogger('my-custom-component');
